This plugin is hacky, but nobody else was going to do it.

Simply fill in the banner URL of up to five payment methods you accept, and the payment gateway URL given to you by your provider.

**Example, using paypal.**

Visit this page: https://www.paypal.com/uk/cgi-bin/webscr?cmd=p/xcl/rec/donate-intro

(Never click a link in an email or a how to.  Make sure you're really on website, etc)

Click the "Get Started" button on the right hand side.

One the next page, you will given a form to fill in.

For "Choose a button type" select "Donations".  For the Organisation/service box, fill in your site name (or something else that obviously relates to you).  Fill in the rest as you see fit.

When you click "create button", you'll be presented with a horrible crappy script.  You don't want that, that's stupid.  Instead, click the "Email" tab, and copy the link from there.  Paste this as the "Link to the payment gateway provided by your payment processor".

Now, click back on the "Website" tab, and then right click on the image in the "buyers view" section.  Either click "copy image location" and use this as the "Image location of your preffered payment method" OR save it, and upload it to your own website, and use that URL instead.

And...that's it.

With other processors, you're on your own - but it's always a simple case of banner URL in the first box, payment gateway URL in the second box.